var classvisual_midi_1_1_sphere =
[
    [ "drawSphere", "classvisual_midi_1_1_sphere.html#aa532428eeb623222c35568c1c62c5bda", null ],
    [ "getOrigin", "classvisual_midi_1_1_sphere.html#a1d9715edd92751d0a52f3484c3381037", null ],
    [ "getPosition", "classvisual_midi_1_1_sphere.html#a06b6e638eb05225f26e2435fb2668daf", null ],
    [ "setPosition", "classvisual_midi_1_1_sphere.html#ab62709ed75371d1da74596e1b74898d9", null ]
];
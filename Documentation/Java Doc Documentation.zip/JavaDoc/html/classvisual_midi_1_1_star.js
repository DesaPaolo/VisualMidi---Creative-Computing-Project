var classvisual_midi_1_1_star =
[
    [ "hideStarField", "classvisual_midi_1_1_star.html#a4757d3ce91c4ce4688a8f3787b0a7a89", null ],
    [ "reShowStarField", "classvisual_midi_1_1_star.html#adb9cd151cf0b56cb7c9de6bd6be4ab1b", null ],
    [ "setColor", "classvisual_midi_1_1_star.html#a9728364ff704b20ce7d0c56751f4dcdd", null ],
    [ "setDensity", "classvisual_midi_1_1_star.html#a40964dcc525dd2788b7cb536af9874c5", null ],
    [ "setOpacity", "classvisual_midi_1_1_star.html#ae3cbfc26cdb2258540c99ac57cb4f603", null ],
    [ "setOverdriveFactor", "classvisual_midi_1_1_star.html#a58ad70b8f31a56d36a35345698a37170", null ],
    [ "setSpeed", "classvisual_midi_1_1_star.html#a3332199ebc7de85eba116c4544100a2a", null ],
    [ "setStarTrack", "classvisual_midi_1_1_star.html#a015cf1fc3074429ccef5ecc0c3de236c", null ],
    [ "setWeight", "classvisual_midi_1_1_star.html#a1279302859c5e2b6c52d1c8c605169de", null ],
    [ "show", "classvisual_midi_1_1_star.html#a2aa97050fb728e15eccfe19c844ab5aa", null ],
    [ "update", "classvisual_midi_1_1_star.html#af67b573f7abe1f47d0ef5e334b7b054b", null ]
];
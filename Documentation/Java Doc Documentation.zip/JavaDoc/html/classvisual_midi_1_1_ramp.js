var classvisual_midi_1_1_ramp =
[
    [ "startRelease", "classvisual_midi_1_1_ramp.html#a4af5bfcc0aa05693885191c2ab83c132", null ],
    [ "trigger", "classvisual_midi_1_1_ramp.html#aa6549939a9621cc0b55b217538de9a4a", null ]
];
var classvisual_midi_1_1_device_menu =
[
    [ "DeviceMenu", "classvisual_midi_1_1_device_menu.html#a3c611d20b46acdc9916494befd9f8b26", null ],
    [ "mousePressedEvent", "classvisual_midi_1_1_device_menu.html#ade287b97d18cf52b5da61f9746d8f2ae", null ],
    [ "showMenu", "classvisual_midi_1_1_device_menu.html#a07add6670cead49ac876514a43b43e25", null ]
];
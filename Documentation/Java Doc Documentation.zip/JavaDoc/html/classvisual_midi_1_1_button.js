var classvisual_midi_1_1_button =
[
    [ "Button", "classvisual_midi_1_1_button.html#a1cd27cb4362e3563fc2ac965c878fb15", null ],
    [ "Button", "classvisual_midi_1_1_button.html#ac0eb27e9716fb02fa51a8ebd8c08817f", null ],
    [ "getBackColor", "classvisual_midi_1_1_button.html#aa8c723b3442cb26fbf2077721eb50689", null ],
    [ "getIndex", "classvisual_midi_1_1_button.html#a7f5ddd68d52cb3103fac06d9d168b23c", null ],
    [ "getText", "classvisual_midi_1_1_button.html#aaa6dd2b28f0b31077cda60c302ff99e7", null ],
    [ "getXPos", "classvisual_midi_1_1_button.html#a9d3890d1dbb09e4537f95838b5742e74", null ],
    [ "getYPos", "classvisual_midi_1_1_button.html#a5b646bccf897927cd13d5983a0eaadb5", null ],
    [ "isPressed", "classvisual_midi_1_1_button.html#a2db7705f1ef81d8aa8c01ecb28b9b9f0", null ],
    [ "setBackgroundColor", "classvisual_midi_1_1_button.html#a4a8ccc85a97e0e56bfe6ba1674d9fb87", null ],
    [ "setIndex", "classvisual_midi_1_1_button.html#a930f716045bae2662c1e5e20bef6a035", null ],
    [ "setText", "classvisual_midi_1_1_button.html#adb6755a10aef0ea8f8f1b1f13c4f54ca", null ],
    [ "showBtn", "classvisual_midi_1_1_button.html#a965863e23bd373b1dd988773c7bcebb7", null ]
];
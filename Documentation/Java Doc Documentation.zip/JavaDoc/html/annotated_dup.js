var annotated_dup =
[
    [ "visualMidi", "classvisual_midi.html", "classvisual_midi" ]
];
var classvisual_midi_1_1_star_field =
[
    [ "StarField", "classvisual_midi_1_1_star_field.html#a3e9c6d31f3a542295c20a54a1ab1239f", null ],
    [ "draw", "classvisual_midi_1_1_star_field.html#a5cfe6ac96ef739437e1d8ec64a3c185c", null ],
    [ "hideStarField", "classvisual_midi_1_1_star_field.html#a86a235d1e54cbe7931917896ced0fbd1", null ],
    [ "reShowStarField", "classvisual_midi_1_1_star_field.html#a99cbc4de0a66cfe14dff4ba0349a8d73", null ],
    [ "setColor", "classvisual_midi_1_1_star_field.html#a021913b476f0e1ba0dd2891124f805ec", null ],
    [ "setDensity", "classvisual_midi_1_1_star_field.html#adaca749c88fc82ab2ee777b470c6a85e", null ],
    [ "setOpacity", "classvisual_midi_1_1_star_field.html#aa8d279107dc8cd7a56c88300ceda6691", null ],
    [ "setOverdriveFactor", "classvisual_midi_1_1_star_field.html#a29f2f1459e0a7a2e78649dcf35f6b648", null ],
    [ "setSpeed", "classvisual_midi_1_1_star_field.html#a96f2db490271c777deaba5f22cf36ab0", null ],
    [ "setStarTrack", "classvisual_midi_1_1_star_field.html#a7f9eb8b9076a3521593f971a096d4c83", null ],
    [ "setWeight", "classvisual_midi_1_1_star_field.html#a4c424aa85e24b01ef7d4592c9b385dc2", null ],
    [ "showSomeStars", "classvisual_midi_1_1_star_field.html#a98dc07743ab04c2d89d55f638032d9cd", null ]
];
var classvisual_midi_1_1_menu =
[
    [ "Menu", "classvisual_midi_1_1_menu.html#a4facf4ad908d087385d06f4178df0f38", null ],
    [ "changeButtonColor", "classvisual_midi_1_1_menu.html#a6d8bc1e98672f453bd9d4aaadff562cb", null ],
    [ "createButtons", "classvisual_midi_1_1_menu.html#a808b5c6277ac24137947cf740c171572", null ],
    [ "mousePressedEvent", "classvisual_midi_1_1_menu.html#abd736f4fe1ab5d039b8a98d24d7a2330", null ],
    [ "showMenu", "classvisual_midi_1_1_menu.html#a5016accceb67899da3bd4a420d7ecfa8", null ]
];
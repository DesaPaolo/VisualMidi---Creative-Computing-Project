var classvisual_midi_1_1_guitar_param_button =
[
    [ "GuitarParamButton", "classvisual_midi_1_1_guitar_param_button.html#ab712a7953f95c0b1f0dc81b916a40d62", null ],
    [ "getValue", "classvisual_midi_1_1_guitar_param_button.html#a74e20a8f9f9ad4a883e9b964a9eaad53", null ],
    [ "setValue", "classvisual_midi_1_1_guitar_param_button.html#a2497ac59ec589aefc307cc73ee0c4ad4", null ]
];
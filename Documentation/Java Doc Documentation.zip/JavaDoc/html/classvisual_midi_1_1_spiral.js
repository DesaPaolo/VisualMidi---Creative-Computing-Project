var classvisual_midi_1_1_spiral =
[
    [ "run", "classvisual_midi_1_1_spiral.html#aecb7a45e2cb1f616e6751e2083fa05cf", null ],
    [ "setOrigin", "classvisual_midi_1_1_spiral.html#a0e7a013b6c7c4566e7e4672d4721127b", null ]
];
var classvisual_midi_1_1_note =
[
    [ "getPitch", "classvisual_midi_1_1_note.html#ae7197948f274323f39b7621ec598ea86", null ],
    [ "noteOnEffect", "classvisual_midi_1_1_note.html#a6786fbc9501d80be4d9e4fa98304ab73", null ],
    [ "setPitch", "classvisual_midi_1_1_note.html#a70a97a0bd516fd5802f9d0363113731b", null ],
    [ "update", "classvisual_midi_1_1_note.html#aef1af23a013e22c7d2ab7c56329d0317", null ]
];
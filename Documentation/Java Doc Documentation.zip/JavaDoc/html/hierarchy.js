var hierarchy =
[
    [ "visualMidi.Button", "classvisual_midi_1_1_button.html", [
      [ "visualMidi.GuitarParamButton", "classvisual_midi_1_1_guitar_param_button.html", null ]
    ] ],
    [ "visualMidi.GuitarProgram", "classvisual_midi_1_1_guitar_program.html", null ],
    [ "visualMidi.Menu", "classvisual_midi_1_1_menu.html", [
      [ "visualMidi.DeviceMenu", "classvisual_midi_1_1_device_menu.html", null ],
      [ "visualMidi.GuitarMenu", "classvisual_midi_1_1_guitar_menu.html", null ],
      [ "visualMidi.LoadMenu", "classvisual_midi_1_1_load_menu.html", null ],
      [ "visualMidi.ProgramStoreMenu", "classvisual_midi_1_1_program_store_menu.html", null ]
    ] ],
    [ "visualMidi.Note", "classvisual_midi_1_1_note.html", null ],
    [ "PApplet", null, [
      [ "visualMidi", "classvisual_midi.html", null ]
    ] ],
    [ "visualMidi.ParticleSystem", "classvisual_midi_1_1_particle_system.html", null ],
    [ "visualMidi.Preset", "classvisual_midi_1_1_preset.html", null ],
    [ "visualMidi.Ramp", "classvisual_midi_1_1_ramp.html", null ],
    [ "visualMidi.Rectangle", "classvisual_midi_1_1_rectangle.html", null ],
    [ "visualMidi.Sphere", "classvisual_midi_1_1_sphere.html", null ],
    [ "visualMidi.Spiral", "classvisual_midi_1_1_spiral.html", null ],
    [ "visualMidi.Star", "classvisual_midi_1_1_star.html", null ],
    [ "visualMidi.StarField", "classvisual_midi_1_1_star_field.html", null ]
];
var searchData=
[
  ['noteoff_298',['noteOff',['../classvisual_midi.html#a41ad787dac56fae0460dc750c0a6ff45',1,'visualMidi']]],
  ['noteon_299',['noteOn',['../classvisual_midi.html#a5a030eae58464d5f1c9ae4bf44a16ea9',1,'visualMidi']]],
  ['noteoneffect_300',['noteOnEffect',['../classvisual_midi_1_1_note.html#a6786fbc9501d80be4d9e4fa98304ab73',1,'visualMidi::Note']]]
];

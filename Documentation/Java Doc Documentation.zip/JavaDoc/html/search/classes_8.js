var searchData=
[
  ['sphere_193',['Sphere',['../classvisual_midi_1_1_sphere.html',1,'visualMidi']]],
  ['spiral_194',['Spiral',['../classvisual_midi_1_1_spiral.html',1,'visualMidi']]],
  ['star_195',['Star',['../classvisual_midi_1_1_star.html',1,'visualMidi']]],
  ['starfield_196',['StarField',['../classvisual_midi_1_1_star_field.html',1,'visualMidi']]]
];

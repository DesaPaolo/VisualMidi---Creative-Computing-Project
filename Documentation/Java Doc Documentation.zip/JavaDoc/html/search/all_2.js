var searchData=
[
  ['changebuttoncolor_13',['changeButtonColor',['../classvisual_midi_1_1_menu.html#a6d8bc1e98672f453bd9d4aaadff562cb',1,'visualMidi::Menu']]],
  ['cleanscreen_14',['cleanScreen',['../classvisual_midi.html#a6bc420882f5b41c7961d6a985b19bc7e',1,'visualMidi']]],
  ['controllerchange_15',['controllerChange',['../classvisual_midi.html#a28a15505999e0bb9ea306e98fa2def81',1,'visualMidi']]],
  ['createbuttons_16',['createButtons',['../classvisual_midi_1_1_menu.html#a808b5c6277ac24137947cf740c171572',1,'visualMidi.Menu.createButtons()'],['../classvisual_midi_1_1_program_store_menu.html#a020e8b18dbb5839b218d891c7156910b',1,'visualMidi.ProgramStoreMenu.createButtons()']]]
];

var searchData=
[
  ['devicemenu_181',['DeviceMenu',['../classvisual_midi_1_1_device_menu.html',1,'visualMidi']]]
];

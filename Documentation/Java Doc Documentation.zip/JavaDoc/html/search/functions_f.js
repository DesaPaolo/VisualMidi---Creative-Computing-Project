var searchData=
[
  ['tostring_368',['toString',['../classvisual_midi_1_1_guitar_program.html#a94e5e999de5f64ae68a8c8257c796efa',1,'visualMidi.GuitarProgram.toString()'],['../classvisual_midi_1_1_preset.html#a80b8cfbe48ece9a040da1b7439fcd81c',1,'visualMidi.Preset.toString()']]],
  ['trigger_369',['trigger',['../classvisual_midi_1_1_ramp.html#aa6549939a9621cc0b55b217538de9a4a',1,'visualMidi::Ramp']]]
];

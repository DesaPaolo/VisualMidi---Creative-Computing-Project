var searchData=
[
  ['button_12',['Button',['../classvisual_midi_1_1_button.html',1,'visualMidi.Button'],['../classvisual_midi_1_1_button.html#a1cd27cb4362e3563fc2ac965c878fb15',1,'visualMidi.Button.Button(int xPos, int yPos, int wid, int hei, String txt)'],['../classvisual_midi_1_1_button.html#ac0eb27e9716fb02fa51a8ebd8c08817f',1,'visualMidi.Button.Button(int xPos, int yPos, int wid, int hei, String txt, int backgroundColor, int textColor)']]]
];

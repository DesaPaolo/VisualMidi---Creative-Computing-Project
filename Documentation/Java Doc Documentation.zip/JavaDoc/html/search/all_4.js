var searchData=
[
  ['endedramp_23',['endedRamp',['../classvisual_midi.html#a55ca0c7704c3d442546147f8f105f3cc',1,'visualMidi']]]
];

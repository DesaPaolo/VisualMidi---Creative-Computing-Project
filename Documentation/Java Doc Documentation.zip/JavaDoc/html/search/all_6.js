var searchData=
[
  ['hidestarfield_80',['hideStarField',['../classvisual_midi_1_1_star.html#a4757d3ce91c4ce4688a8f3787b0a7a89',1,'visualMidi.Star.hideStarField()'],['../classvisual_midi_1_1_star_field.html#a86a235d1e54cbe7931917896ced0fbd1',1,'visualMidi.StarField.hideStarField()']]]
];

var searchData=
[
  ['ramp_109',['Ramp',['../classvisual_midi_1_1_ramp.html',1,'visualMidi']]],
  ['rectangle_110',['Rectangle',['../classvisual_midi_1_1_rectangle.html',1,'visualMidi.Rectangle'],['../classvisual_midi_1_1_rectangle.html#a6475b4765844e7f168ae041d934d19d0',1,'visualMidi.Rectangle.Rectangle()']]],
  ['removenotebypitch_111',['removeNoteByPitch',['../classvisual_midi.html#a986fd763dc8c4630d15a5b5f41fa1d26',1,'visualMidi']]],
  ['removepsbyorigin_112',['removePsByOrigin',['../classvisual_midi.html#aa90341e25471b3ec31a9040e30c6988a',1,'visualMidi']]],
  ['reshowstarfield_113',['reShowStarField',['../classvisual_midi_1_1_star.html#adb9cd151cf0b56cb7c9de6bd6be4ab1b',1,'visualMidi.Star.reShowStarField()'],['../classvisual_midi_1_1_star_field.html#a99cbc4de0a66cfe14dff4ba0349a8d73',1,'visualMidi.StarField.reShowStarField()']]],
  ['run_114',['run',['../classvisual_midi_1_1_spiral.html#aecb7a45e2cb1f616e6751e2083fa05cf',1,'visualMidi::Spiral']]]
];

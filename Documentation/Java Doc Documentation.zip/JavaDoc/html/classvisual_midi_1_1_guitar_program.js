var classvisual_midi_1_1_guitar_program =
[
    [ "GuitarProgram", "classvisual_midi_1_1_guitar_program.html#a3240b735cd794d8c0fd35a13ea839f7f", null ],
    [ "GuitarProgram", "classvisual_midi_1_1_guitar_program.html#ad0a7c5b2b45a216160e15f47c9f63647", null ],
    [ "getAmp", "classvisual_midi_1_1_guitar_program.html#a96a9f81432cda950a429b3256319f377", null ],
    [ "getEq", "classvisual_midi_1_1_guitar_program.html#abf364065bb51419e3749088d0aaa1eda", null ],
    [ "getModulation", "classvisual_midi_1_1_guitar_program.html#aae9fda68eb04e97bd46b366933a19437", null ],
    [ "getName", "classvisual_midi_1_1_guitar_program.html#aebc4ac1af09a6c36c2898fda71a6df46", null ],
    [ "getOverdrive", "classvisual_midi_1_1_guitar_program.html#a5aed1f20711fcde4f95a6d78d135e3de", null ],
    [ "getReverb", "classvisual_midi_1_1_guitar_program.html#aeeeae208a25d7c9fb41c511ba29ef767", null ],
    [ "setAmp", "classvisual_midi_1_1_guitar_program.html#a651f7322b5ddc2456b4909e13733bf76", null ],
    [ "setEq", "classvisual_midi_1_1_guitar_program.html#a44023c62818ecbf61575ffd14d5cd47b", null ],
    [ "setModulation", "classvisual_midi_1_1_guitar_program.html#a89d983d72d1cc04cedd2a4ec92686cf4", null ],
    [ "setName", "classvisual_midi_1_1_guitar_program.html#a8d08574c057d73f9aa2f69b2a4c70735", null ],
    [ "setOverdrive", "classvisual_midi_1_1_guitar_program.html#aaf346370dec122b7188e1f9c7ad3e9c1", null ],
    [ "setReverb", "classvisual_midi_1_1_guitar_program.html#a7d78da153581697d26c7113b90afd6f3", null ],
    [ "toString", "classvisual_midi_1_1_guitar_program.html#a94e5e999de5f64ae68a8c8257c796efa", null ]
];